# elegantframeworks
Code stubs for Elegant Automation Frameworks with Python and Pytest (Udemy)
